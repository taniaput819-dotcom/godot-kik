extends Node


func _on_button_pressed() -> void:
	get_tree().change_scene_to_file("res://Latihan.tscn")


func _on_texture_button_pressed() -> void:
	get_tree().change_scene_to_file("res://KIKGAME.tscn")


func _on_texture_button_2_pressed() -> void:
	get_tree().quit()
